print(
turtle.getFuelLevel()
)
